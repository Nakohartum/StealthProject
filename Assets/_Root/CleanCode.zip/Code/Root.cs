﻿using System;
using _Root.Code.AStar;
using _Root.Code.AStar.Pathfinder;
using _Root.Code.Input;
using _Root.Code.QuestFeature.Controller;
using GameOne.Player;
using UnityEngine;
using Zenject;

namespace _Root.Code
{
    public class Root : MonoBehaviour
    {
        // [Inject] private MainMenuManager _menuManager;
        private void Start()
        {
            // _menuManager.OpenMainMenu();
            Debug.Log(ProjectContext.HasInstance);
        }
    }
}