﻿using System.Collections.Generic;
using System.Numerics;

namespace _Root.CleanCode.Shared.Ports
{
    public interface ITime
    {
        /// <summary>Delta time in seconds since last tick.</summary>
        float DeltaTime { get; }
        /// <summary>Time in seconds since app start.</summary>
        float TimeSinceStart { get; }
    }

    /// <summary>
    /// Input boundary consumed by Application layer (e.g., player use-cases).
    /// </summary>
    public interface IInputPort
    {
        /// <summary>Movement vector.</summary>
        Vec2 Move();
        /// <summary>True once when the user requests stealth toggle.</summary>
        bool StealthToggle();
        /// <summary>True once when the user requests quick save.</summary>
        bool QuickSave();
        /// <summary>True once when the user requests quick load.</summary>
        bool QuickLoad();
    }

    /// <summary>
    /// Pathfinding boundary abstracting custom A* (no Unity types).
    /// </summary>
    public interface INavigationPort
    {
        /// <summary>Try to find a path from A to B.</summary>
        bool TryFindPath(Vec2 from, Vec2 to, out IReadOnlyList<Vec2> path);

        /// <summary>Enable or disable a dynamic obstacle by AABB.</summary>
        void SetDynamicObstacle(Rect2 aabb, bool enabled);
    }
    
}